/**
 * 
 */
package com.oirs.dao;

import com.oirs.bean.userBean;
import com.oirs.exception.OIRSException;

/**
 * @author gowthc
 *
 */
public interface IOnlineInternalRecDAO {
	public abstract userBean loginUser(String userName,String userPassword) throws OIRSException;
	public abstract boolean validatingUser(String Id, String password);
}
