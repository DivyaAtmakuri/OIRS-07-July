package com.oirs.service;

public interface IXMLAuthenticationService {

}
