package com.oirs.service;

import com.oirs.bean.userBean;
import com.oirs.dao.IOnlineInternalRecDAO;
import com.oirs.dao.OnlineInternalRecDAOImpl;
import com.oirs.exception.OIRSException;

public class OnlineInternalRecServiceImpl implements IOnlineInternalRecService {

	@Override
	public userBean loginUser(String userName, String userPassword)
			throws OIRSException {
		// TODO Auto-generated method stub
		
		return null;
	}

	@Override
	public boolean isValidUserName(String Name) {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean ValidateUser(String Id, String password) {
		IOnlineInternalRecDAO dao = new OnlineInternalRecDAOImpl();
		dao.validatingUser(Id, password);
		return false;
	}

}
