package com.oirs.service;

import java.util.List;

import com.oirs.bean.EmployeeBean;
import com.oirs.bean.ProjectBean;
import com.oirs.bean.RequisitionBean;
import com.oirs.dao.IRMDAO;
import com.oirs.dao.RMDAOImpl;
import com.oirs.exception.OIRSException;

public class RMServiceImpl implements IRMService {

	IRMDAO iRMDAO = new RMDAOImpl(); 
	@Override
	public String raiseRequisition(RequisitionBean reqBean)
			throws OIRSException {
		// TODO Auto-generated method stub
		String reqId = iRMDAO.raiseRequisition(reqBean); 
		return reqId;
	}

	@Override
	public List<EmployeeBean> viewRequestRes(String reqId) throws OIRSException {
		// TODO Auto-generated method stub
		List<EmployeeBean> bean = iRMDAO.viewRequestRes(reqId);
		return bean;
	}

	@Override
	public List<String> getReqIds(String rmId) throws OIRSException {
		// TODO Auto-generated method stub
		List<String> reqIds = iRMDAO.getReqIds(rmId);
		return reqIds;
	}

	@Override
	public List<ProjectBean> getProjectDetails(String rmId)
			throws OIRSException {
		// TODO Auto-generated method stub
		List<ProjectBean> bean = iRMDAO.getProjectDetails(rmId);
		return bean;
	}

	@Override
	public List<RequisitionBean> getRequisitionDetails(String rmId)
			throws OIRSException {
		// TODO Auto-generated method stub
		List<RequisitionBean> bean = iRMDAO.getRequisitionDetails(rmId);
		return bean;
	}

	@Override
	public List<RequisitionBean> getRequisitionDetailsByStatus(String rmId,
			String status) throws OIRSException {
		// TODO Auto-generated method stub
		List<RequisitionBean> bean = iRMDAO.getRequisitionDetailsByStatus(rmId, status);
		return bean;
	}

	@Override
	public boolean closeProject(String prjId) throws OIRSException {
		// TODO Auto-generated method stub
		boolean result = iRMDAO.closeProject(prjId);
		return result;
	}

	@Override
	public boolean updateEmpPrjId(String empId, String prjId)
			throws OIRSException {
		// TODO Auto-generated method stub
		boolean result = iRMDAO.updateEmpPrjId(empId, prjId);
		return result;
	}

	@Override
	public boolean acceptRes(String empId,String reqId) throws OIRSException {
		// TODO Auto-generated method stub
		boolean result = iRMDAO.acceptRes(empId,reqId);
		return result;
	}

	@Override
	public boolean rejectRes(String empId,String reqId) throws OIRSException {
		// TODO Auto-generated method stub
		boolean result = iRMDAO.rejectRes(empId,reqId);
		return result;
	}

	@Override
	public boolean unassignProject(String empId) throws OIRSException {
		// TODO Auto-generated method stub
		boolean result = iRMDAO.unassignProject(empId);
		return result;
	}

	@Override
	public boolean unassignByPrjId(String prjId) throws OIRSException {
		// TODO Auto-generated method stub
		boolean result = iRMDAO.unassignByPrjId(prjId);
		return result;
	}

	@Override
	public void generateReport() throws OIRSException {
		// TODO Auto-generated method stub

	}

	@Override
	public List<ProjectBean> getProjectDetailsByStatus(String rmId,
			String status) throws OIRSException {
		// TODO Auto-generated method stub
		List<ProjectBean> list = iRMDAO.getProjectDetailsByStatus(rmId, status);
		return list;
	}

	@Override
	public List<EmployeeBean> getEmpDetailsByPrjId(String prjId)
			throws OIRSException {
		// TODO Auto-generated method stub
		List<EmployeeBean> bean = iRMDAO.getEmpDetailsByPrjId(prjId);
		return bean;
	}

}
